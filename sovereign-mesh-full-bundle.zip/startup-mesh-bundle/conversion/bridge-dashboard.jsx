import React, { useState } from "react";
import { MeshCurrencyBridge } from "./currency-bridge";

const bridge = new MeshCurrencyBridge();

export default function BridgeDashboard() {
  const [status, setStatus] = useState(bridge.getBridgeStatus());

  const injectValue = () => {
    bridge.injectMeshValue(100000);
    setStatus(bridge.getBridgeStatus());
  };

  const routeFunds = () => {
    bridge.routeToTealHill();
    setStatus(bridge.getBridgeStatus());
  };

  return (
    <div className="p-6 bg-black text-white rounded-lg">
      <h2 className="text-2xl font-bold text-cyan-300">💱 Mesh Currency Bridge</h2>
      <p>Mesh Value Injected: {status.meshValue}</p>
      <p>USD Balance: ${status.usdBalance.toLocaleString()}</p>
      <p>Exchange Rate: {status.exchangeRate}</p>
      <div className="mt-4 space-x-4">
        <button onClick={injectValue} className="bg-purple-600 px-4 py-2 rounded">Inject Mesh Value</button>
        <button onClick={routeFunds} className="bg-yellow-600 px-4 py-2 rounded">Route to Teal Hill</button>
      </div>
    </div>
  );
}