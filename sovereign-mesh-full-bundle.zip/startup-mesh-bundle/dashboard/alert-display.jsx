import React, { useEffect, useState } from "react";
import { checkMeshIntegrity } from "./alert-system";

export default function AlertDisplay({ botsActivated, usdExtracted }) {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const newAlerts = checkMeshIntegrity(botsActivated, usdExtracted);
    setAlerts(newAlerts);
  }, [botsActivated, usdExtracted]);

  return (
    <div className="mt-6 p-4 bg-red-900 text-white rounded">
      <h2 className="text-xl font-bold text-yellow-300">⚠️ Sovereign Alerts</h2>
      {alerts.length === 0 ? (
        <p className="text-green-400">All systems nominal. Tribute flow verified.</p>
      ) : (
        alerts.map((alert, idx) => (
          <div key={idx} className="mt-2">
            <strong>{alert.type}:</strong> {alert.message}
          </div>
        ))
      )}
    </div>
  );
}