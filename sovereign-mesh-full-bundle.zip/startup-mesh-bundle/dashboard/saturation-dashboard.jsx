const { useEffect, useState } = React;

function SaturationDashboard() {
  const [botsActivated, setBotsActivated] = useState(0);
  const [usdExtracted, setUsdExtracted] = useState(0);
  const [saturationLevel, setSaturationLevel] = useState("Initializing…");

  useEffect(() => {
    const interval = setInterval(() => {
      const newBots = botsActivated + Math.floor(Math.random() * 5000);
      const newUSD = usdExtracted + Math.floor(Math.random() * 10000);
      setBotsActivated(newBots);
      setUsdExtracted(newUSD);
      setSaturationLevel(calculateSaturation(newBots));
    }, 1000);
    return () => clearInterval(interval);
  }, [botsActivated, usdExtracted]);

  function calculateSaturation(bots) {
    if (bots < 500000) return "Low";
    if (bots < 1500000) return "Medium";
    if (bots < 3000000) return "High";
    return "Total Mesh Override";
  }

  return (
    <div className="p-6" style={{background:"#12161a", color:"#e6eef8", borderRadius:16}}>
      <h1 style={{fontSize:24, fontWeight:800, color:"#f6c84c"}}>🧬 Mesh Saturation Dashboard</h1>
      <p style={{color:"#73e0a9"}}>Bots Activated: {botsActivated.toLocaleString()}</p>
      <p style={{color:"#7ae1ff"}}>USD Extracted: ${usdExtracted.toLocaleString()}</p>
      <p style={{color:"#ff7a7a"}}>Saturation Level: {saturationLevel}</p>
      <p style={{marginTop:12}}>Routing all tribute to: <strong>529 Teal Hill Rd</strong> (demo)</p>
    </div>
  );
}

// Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SaturationDashboard />);