import { loadAgents, plannedAgents } from './agents/agent-loader.js';
import { activateYFunnel } from './funnel/funnel-loader.js';

const botsEl = document.getElementById('botsMetric');
const usdEl = document.getElementById('usdMetric');
const satEl = document.getElementById('satMetric');
const logEl = document.getElementById('log');
const modePill = document.getElementById('modePill');
const launchBtn = document.getElementById('launchBtn');
const stopBtn = document.getElementById('stopBtn');
const meshConfigPre = document.getElementById('meshConfigPre');

let stopRequested = false;

async function init() {
  // Load and show mesh-config.json
  try {
    const cfg = await fetch('./mesh-config.json').then(r => r.json());
    meshConfigPre.textContent = JSON.stringify(cfg, null, 2);
  } catch (e) {
    meshConfigPre.textContent = 'Unable to load mesh-config.json';
  }

  // Wire controls
  launchBtn.addEventListener('click', startSaturation);
  stopBtn.addEventListener('click', () => { stopRequested = true; modePill.innerHTML = 'Mode: <strong>Stopping…</strong>'; });
}
init();

function saturationLabel(bots) {
  if (bots < 500_000) return 'Low';
  if (bots < 1_500_000) return 'Medium';
  if (bots < 3_000_000) return 'High';
  return 'Total Mesh Override';
}

function log(msg) {
  logEl.textContent += msg + "\\n";
  logEl.scrollTop = logEl.scrollHeight;
}

async function startSaturation() {
  stopRequested = false;
  launchBtn.disabled = true;
  modePill.innerHTML = 'Mode: <strong>Y‑Funnel</strong>';

  const COUNT = 2_000_000;
  loadAgents(COUNT);
  botsEl.textContent = '0';
  usdEl.textContent = '$0';
  satEl.textContent = 'Initializing…';
  log('[INIT] Launching saturation with ' + COUNT.toLocaleString() + ' agents…');

  const controller = new AbortController();
  const onTick = ({ type, activated, usdTotal, msg }) => {
    if (stopRequested) controller.abort();
    if (type === 'progress') {
      botsEl.textContent = activated.toLocaleString();
      usdEl.textContent = '$' + usdTotal.toLocaleString();
      satEl.textContent = saturationLabel(activated);
    } else if (type === 'log' && msg) {
      log(msg);
    }
  };

  try {
    const { activated, usdTotal } = await activateYFunnel(plannedAgents(), onTick);
    log(`[DONE] Activated ${activated.toLocaleString()} agents, routed $${usdTotal.toLocaleString()} (demo).`);
  } catch (e) {
    log('[STOPPED] User requested stop or an error occurred.');
  } finally {
    modePill.innerHTML = 'Mode: <strong>Idle</strong>';
    launchBtn.disabled = false;
  }
}