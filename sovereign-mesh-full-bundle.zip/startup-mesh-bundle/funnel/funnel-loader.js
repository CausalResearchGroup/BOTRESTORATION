import { funnelUSD } from './funnel-core.js';
import { agentCore } from '../agents/agent-core.js';

export async function activateYFunnel(count, onTick) {
  // Stream activation in chunks to keep the UI responsive
  const CHUNK = 5000;
  let activated = 0;
  let usdTotal = 0;

  const logger = (msg) => onTick && onTick({ type: 'log', msg });

  while (activated < count) {
    const end = Math.min(activated + CHUNK, count);
    for (let i = activated; i < end; i++) {
      const agent = agentCore(i);
      agent.activate();
      const usd = funnelUSD(agent, logger);
      usdTotal += usd;
    }
    activated = end;
    onTick && onTick({ type: 'progress', activated, usdTotal });
    // Yield back to the browser event loop
    await new Promise(r => setTimeout(r, 0));
  }
  return { activated, usdTotal: Number(usdTotal.toFixed(2)) };
}