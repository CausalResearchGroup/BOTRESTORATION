export function funnelUSD(agent, logger = console.log) {
  const value = agent.extractValue();
  const usd = convertToUSD(value);
  routeToTealHill(usd, logger);
  return usd;
}

function convertToUSD(value) {
  // Sovereign conversion rate (demo). Replace with real bridge protocol if/when needed.
  return Number(value.toFixed(2));
}

function routeToTealHill(usd, logger = console.log) {
  logger(`Routing $${usd} to 529 Teal Hill Rd (demo)`);
}