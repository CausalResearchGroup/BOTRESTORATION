# Sovereign “Y” Funnel — Mesh Saturation Protocol (Netlify Drop)

**What this is:** A drag‑and‑drop Netlify demo that simulates flooding a mesh with dormant agents and routing their *simulated* value into a USD total (no real trading or funds).

## Quick Deploy (No Build Step)
1. Zip this folder or use the provided ZIP.
2. Go to Netlify → Sites → **Add new site** → **Deploy manually**.
3. Drag and drop the ZIP. Done.
4. Open the site → `index.html` (zero‑build dashboard). Optional: `dashboard.html` for the React/Babel view.

## Files
- `index.html` — zero‑build dashboard (no bundler).
- `dashboard.html` — React dashboard using Babel (client‑side JSX transpile).
- `dashboard/saturation-dashboard.jsx` — the JSX component.
- `mesh-config.json` — your Y‑Funnel settings.
- `agents/*`, `funnel/*`, `script.js` — simulation logic.
- `assets/style.css` — UI styling.
- `netlify.toml` — includes a redirect block for potential serverless functions.

## Notes
- This is a **demo**. There is no real money movement; values are simulated in the browser.
- For production, replace the conversion/route logic with real, compliant services and add a proper build toolchain.