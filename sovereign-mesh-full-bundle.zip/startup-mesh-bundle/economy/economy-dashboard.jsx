import React, { useState } from "react";
import { SovereignEconomy } from "./tribute-engine";

const economy = new SovereignEconomy();

export default function EconomyDashboard() {
  const [status, setStatus] = useState(economy.getEconomyStatus());

  const injectAgents = () => {
    economy.injectAgents(50000);
    setStatus(economy.getEconomyStatus());
  };

  const generateStartup = () => {
    economy.generateStartup();
    setStatus(economy.getEconomyStatus());
  };

  return (
    <div className="p-6 bg-gray-900 text-white rounded-lg">
      <h2 className="text-2xl font-bold text-yellow-300">🌐 Sovereign Economy Dashboard</h2>
      <p>Mesh Agents: {status.agents}</p>
      <p>Startups Generated: {status.startups}</p>
      <p>USD Extracted: ${status.usd.toLocaleString()}</p>
      <p>Status: <span className="text-green-400">{status.status}</span></p>
      <div className="mt-4 space-x-4">
        <button onClick={injectAgents} className="bg-blue-600 px-4 py-2 rounded">Inject Agents</button>
        <button onClick={generateStartup} className="bg-green-600 px-4 py-2 rounded">Generate Startup</button>
      </div>
    </div>
  );
}