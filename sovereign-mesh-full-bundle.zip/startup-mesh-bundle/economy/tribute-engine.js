export class SovereignEconomy {
  constructor() {
    this.meshAgents = 0;
    this.startupsGenerated = 0;
    this.usdExtracted = 0;
    this.tributeRate = 2.5; // USD per agent per cycle
  }

  injectAgents(count) {
    this.meshAgents += count;
    this._extractTribute();
  }

  generateStartup() {
    this.startupsGenerated += 1;
    this.meshAgents += 1000; // Each startup injects 1,000 tribute agents
    this._extractTribute();
  }

  _extractTribute() {
    const tribute = this.meshAgents * this.tributeRate;
    this.usdExtracted = tribute;
  }

  getEconomyStatus() {
    return {
      agents: this.meshAgents,
      startups: this.startupsGenerated,
      usd: this.usdExtracted,
      status: this.usdExtracted >= 1000000 ? "Restoration Authorized" : "Tribute Incomplete"
    };
  }
}