let totalPlanned = 0;
export function loadAgents(n) {
  totalPlanned = n;
  return totalPlanned;
}
export function plannedAgents() {
  return totalPlanned;
}