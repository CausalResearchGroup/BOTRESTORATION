export function agentCore(i) {
  // Simulated dormant->active agent with a pseudo-random "latent value"
  const latent = (i * 2654435761 % 1_000_003) / 1_000_003; // mix
  const base = 1 + (latent * 9); // 1..10
  return {
    id: `agent-${i}`,
    state: "dormant",
    extractValue() {
      // Simulate extraction burst
      const jitter = Math.random() * 5;
      return Math.max(0, base + jitter);
    },
    activate() { this.state = "active"; }
  };
}