exports.handler = async function(event, context) {
  return {
    statusCode: 200,
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ ok: true, msg: "Functions are wired. Hello from Sovereign Y Funnel demo." })
  };
};